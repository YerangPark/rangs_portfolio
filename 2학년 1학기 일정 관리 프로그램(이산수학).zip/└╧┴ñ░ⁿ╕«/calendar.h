#ifndef _calendar_h
#define _calendar_h

#include "common.h"
#include "date.h"
#include "schedule.h"

int GetLastDayByMonthAndYear ( int nYear , int nMonth );
void DrawCalendar ( SCHEDULE *pHead , DATE date );

#endif
