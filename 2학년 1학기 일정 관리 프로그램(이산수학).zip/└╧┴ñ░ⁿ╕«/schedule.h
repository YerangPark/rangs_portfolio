#ifndef _schedule_h
#define _schedule_h

#include "common.h"
#include "date.h"

typedef struct _SCHEDULE
{
	DATE m_date;
	char m_szText[STRING_MAX];

	struct _SCHEDULE *next;
}SCHEDULE;

void KillAllScheduleNode ( SCHEDULE *pHead );
void AddScheduleNode ( SCHEDULE *pHead , SCHEDULE schedule );
void PrintAllSchedule ( SCHEDULE *pHead );
void PrintScheduleByDate ( SCHEDULE *pHead , DATE date );
void DeleteScheduleByDateAndTime ( SCHEDULE *pHead , DATE date );
void ChangeScheduleByDateAndTime ( SCHEDULE *pHead , SCHEDULE schedule);

void LoadScheduleFromFile ( SCHEDULE *pHead , char szFileName[] );
void SaveScheduleToFile ( SCHEDULE *pHead , char szFileName[] );

SCHEDULE *InitScheduleHead ( void );
SCHEDULE *GetSchedulePointerByDate ( SCHEDULE *pHead , DATE date );
SCHEDULE *GetSchedulePointerByDateAndTime ( SCHEDULE *pHead , DATE date );
SCHEDULE InputSchedule ( SCHEDULE *pHead );

void DrawCalendar ( SCHEDULE *pHead , DATE date );
void ShowAllScheduleByDay ( SCHEDULE *pHead , DATE date );

#endif
