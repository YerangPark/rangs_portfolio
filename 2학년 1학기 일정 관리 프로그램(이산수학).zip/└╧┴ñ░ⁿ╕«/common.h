#ifndef _common_h
#define _common_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define STRING_MAX 3000
#define FILENAME "schedule.txt"

typedef unsigned int BOOL;

enum
{
	FALSE ,
	TRUE
};

#endif
