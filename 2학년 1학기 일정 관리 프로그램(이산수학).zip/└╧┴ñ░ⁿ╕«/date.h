#ifndef _date_h
#define _date_h

#include "common.h"

typedef struct _DATE
{
	int m_nYear;
	int m_nMonth;
	int m_nDay;
	int m_nHour;
	int m_nMinute;
}DATE;

void PrintDate ( DATE date );
void ModifyMonth ( DATE *pDate , int nMonth );
void ModifyDay ( DATE *pDate , int nDay );

int CompareDate ( DATE target , DATE compare );
int CompareDateAndTime ( DATE target , DATE compare );

DATE InputDate ( void );
DATE GetToday ( void );
DATE current;

#endif
